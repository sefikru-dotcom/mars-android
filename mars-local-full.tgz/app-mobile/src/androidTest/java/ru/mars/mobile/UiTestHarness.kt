package ru.mars.mobile

import android.content.Context
import android.os.SystemClock
import android.view.View
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import androidx.test.platform.app.InstrumentationRegistry
import org.hamcrest.Matcher
import org.hamcrest.Matchers.not
import ru.mars.mobile.offline.OfflineStores
import ru.mars.network.cache.SessionOfflineCache
import ru.mars.network.credential.AndroidKeyStoreCredentialStore
import ru.mars.network.model.ConsumedDeviceCredential
import ru.mars.network.model.SessionItem
import ru.mars.network.model.SessionMessage

/**
 * Детерминированный harness для instrumented UI-тестов (Espresso).
 *
 * Задача: проверить настоящую ручную View-вёрстку на эмуляторе БЕЗ боевого
 * сервера и без симуляции результата JVM-contract-тестом. Поэтому:
 *
 * 0. **Жёсткий guard (GAP-2)**: любое изменение состояния устройства возможно
 *    только на эмуляторе — каждый изменяющий метод этого harness начинается с
 *    [DeviceSafetyGuard.requireEmulator], а [EmulatorOnlyTestRunner] вообще не
 *    запускает тесты на физическом устройстве (fail-closed: неизвестное
 *    устройство считается физическим). Тесты собираются против изолированного
 *    варианта `uiTest` (applicationIdSuffix `.uitest`, см. build.gradle.kts):
 *    собственный пакет `ru.mars.mobile.uitest` со своим data-каталогом и своим
 *    UID-пространством AndroidKeyStore — боевой `ru.mars.mobile` на любом
 *    устройстве не заменяется и не затрагивается. Радио — глобальный эффект,
 *    поэтому guard обязателен даже при изоляции пакетом. Регрессионные
 *    проверки самого guard: [DeviceSafetyGuardTest].
 * 1. **Радио выключается** shell-командами эмулятора (`svc wifi/data disable`) —
 *    сетевые запросы падают быстро и одинаково, боевой `marscore.ru` не
 *    затрагивается вообще.
 * 2. **Авторизация — настоящий [AndroidKeyStoreCredentialStore]** с фейковым
 *    токеном: экраны проходят свой guard `store.read() != null` ровно тем же
 *    кодом, что и в проде; сервер фейковый токен отклонил бы, но на офлайн-UI
 *    это не влияет (репозитории на сбое возвращают пустой результат).
 * 3. **Данные — seeded [SessionOfflineCache]** (тот же класс и тот же
 *    SharedPreferences-файл, что использует прод-код): при пустом сетевом
 *    ответе `reconcile` показывает сохранённый снимок, поэтому список
 *    диалогов, parent/subagent-дерево и офлайн-копия транскрипта полностью
 *    детерминированы.
 *
 * Тесты НЕ отправляют сообщения: 401 на send-пути вызывает forced re-auth
 * ([AuthRejectionPolicy]) — это единственная ветка, требующая живого сервера.
 */
object UiTestHarness {

    val targetContext: Context =
        InstrumentationRegistry.getInstrumentation().targetContext

    // --- Фикстура списка диалогов: parent + subagent-ребёнок + независимая сессия ---
    const val PARENT_SESSION_ID = "s-parent"
    const val CHILD_SESSION_ID = "s-child"
    const val OTHER_SESSION_ID = "s-other"
    const val PARENT_TITLE = "Родительский диалог"
    const val CHILD_TITLE = "Дочерний воркер"
    const val OTHER_TITLE = "Отдельный чат"
    const val CACHED_MESSAGE_TEXT = "Привет из офлайн-кэша"
    const val OFFLINE_HINT = "Нет связи — показана сохранённая копия диалога"

    /**
     * Выполняет shell-команду от имени instrumentation (права shell) и дожидается вывода.
     * Guard: только эмулятор — shell-права позволяют изменить что угодно, поэтому
     * команда даже не отправляется на физическом устройстве.
     */
    fun shell(command: String) {
        DeviceSafetyGuard.requireEmulator("UiTestHarness.shell(\"$command\")")
        val automation = InstrumentationRegistry.getInstrumentation().uiAutomation
        automation.executeShellCommand(command).use { pfd ->
            // Команда реально исполняется только при полном чтении потока вывода.
            android.os.ParcelFileDescriptor.AutoCloseInputStream(pfd).use { it.readBytes() }
        }
    }

    fun radioOff() {
        DeviceSafetyGuard.requireEmulator("UiTestHarness.radioOff")
        shell("svc wifi disable")
        shell("svc data disable")
    }

    fun radioOn() {
        DeviceSafetyGuard.requireEmulator("UiTestHarness.radioOn")
        shell("svc wifi enable")
        shell("svc data enable")
    }

    /**
     * Полный сброс локального состояния приложения между тестами: credential,
     * офлайн-кэш, черновики, очередь офлайн-отправки и все персистентные выборы
     * (модель/reasoning/режим активности), чтобы каждый тест стартовал с
     * известного состояния.
     *
     * Guard: на физическом устройстве сброс отклоняется ДО первого обращения к
     * Keystore/prefs (изолированный пакет `ru.mars.mobile.uitest` — второй
     * уровень защиты: боевой пакет тесты не видят вообще).
     */
    fun resetState() {
        DeviceSafetyGuard.requireEmulator("UiTestHarness.resetState")
        AndroidKeyStoreCredentialStore(targetContext).clear()
        // Прод-хранилище офлайн-слоя — SQLite: чистим его целиком, иначе фикстуры
        // предыдущего теста (кэш диалогов, очередь отправки) протекают в следующий.
        OfflineStores.clearAll(targetContext)
        listOf(
            "mars-offline-cache",
            "mars-session-drafts",
            "mars-pending-messages",
            "mars-model-choice",
            "mars-reasoning-choice",
            "mars-activity-mode",
            "mars-workspace-choice",
            "mars-auto-compression",
            "mars-music-search-history",
        ).forEach { name ->
            targetContext.getSharedPreferences(name, Context.MODE_PRIVATE)
                .edit().clear().commit()
        }
    }

    /**
     * Выдаёт runtime-разрешения, которые приложение запрашивает при старте, ДО запуска
     * активности.
     *
     * Зачем: `ChatActivity` на входе вызывает `PushNotifications.ensurePostPermission`, и на
     * API 33+ системный диалог POST_NOTIFICATIONS уводит активность из RESUMED. Espresso
     * считает такую активность отсутствующей (`NoActivityResumedException`), и UI-тест падает
     * не на своём предмете, а на модальном диалоге ОС. `pm grant` снимает диалог, оставляя
     * поведение приложения неизменным.
     */
    fun grantRuntimePermissions() {
        DeviceSafetyGuard.requireEmulator("UiTestHarness.grantRuntimePermissions")
        listOf(
            android.Manifest.permission.POST_NOTIFICATIONS,
            android.Manifest.permission.RECORD_AUDIO,
        ).forEach { permission ->
            shell("pm grant ${targetContext.packageName} $permission")
        }
    }

    /**
     * Будит устройство и снимает keyguard.
     *
     * Headless-эмулятор блокируется повторно ВО ВРЕМЯ прогона: одного снятия в
     * workflow мало, потому что экран гаснет между тестами, и дальше любое окно
     * остаётся без window focus (`has-window-focus=false`) — падают все UI-тесты
     * подряд, независимо от проверяемого поведения. Звать в `@Before` каждого
     * теста, который поднимает активность.
     */
    fun wakeAndUnlock() {
        DeviceSafetyGuard.requireEmulator("UiTestHarness.wakeAndUnlock")
        val device = androidx.test.uiautomator.UiDevice.getInstance(
            InstrumentationRegistry.getInstrumentation()
        )
        runCatching { device.wakeUp() }
        runCatching { device.pressMenu() }
        // `wm dismiss-keyguard` требует shell-прав — они есть у instrumentation.
        shell("wm dismiss-keyguard")
        // keyevent 82 (MENU) на API 34 сам keyguard не снимает, нужен свайп вверх.
        if (runCatching { device.isNaturalOrientation }.getOrDefault(true)) {
            runCatching {
                device.swipe(
                    device.displayWidth / 2,
                    (device.displayHeight * 0.85f).toInt(),
                    device.displayWidth / 2,
                    (device.displayHeight * 0.25f).toInt(),
                    20,
                )
            }
        }
    }

    /** Сохраняет фейковый native-credential настоящим прод-хранилищем (только эмулятор). */
    fun seedCredential() {
        DeviceSafetyGuard.requireEmulator("UiTestHarness.seedCredential")
        AndroidKeyStoreCredentialStore(targetContext).save(
            ConsumedDeviceCredential(
                accessToken = "ui-test-token",
                tokenType = "Bearer",
                deviceId = "ui-test-device",
                scopes = listOf("chat"),
                expiresIn = 3600,
            )
        )
    }

    /**
     * Кладёт в прод-кэш ([SessionOfflineCache]) снимок списка диалогов и
     * транскрипт родительской сессии. При выключенном радио список диалогов и
     * открытый диалог показывают ровно эти данные.
     *
     * Хранилище берётся из [OfflineStores] — того же слоя, что читает приложение
     * (SQLite с TTL по умолчанию), а не из SharedPreferences: прод переехал на
     * SQLite, и фикстура, записанная в prefs, экраном не видна — список пуст,
     * тесты падают на «Диалогов пока нет», хотя wiring исправен.
     */
    fun seedSessionCache() {
        DeviceSafetyGuard.requireEmulator("UiTestHarness.seedSessionCache")
        val cache = OfflineStores.sessionCache(targetContext)
        val saved = cache.saveSessions(
            listOf(
                SessionItem(
                    id = PARENT_SESSION_ID,
                    title = PARENT_TITLE,
                    preview = "сводка родительского диалога",
                    createdAt = "2026-10-01T08:00:00",
                    updatedAt = "2026-10-01T10:00:00",
                    messageCount = 2,
                ),
                SessionItem(
                    id = CHILD_SESSION_ID,
                    title = CHILD_TITLE,
                    preview = "делегированная подзадача",
                    createdAt = "2026-10-01T08:30:00",
                    updatedAt = "2026-10-01T09:00:00",
                    messageCount = 1,
                    sourceTag = "subagent",
                    rawSource = "subagent",
                    sourceLabel = "Subagent",
                    readOnly = true,
                    parentSessionId = PARENT_SESSION_ID,
                ),
                SessionItem(
                    id = OTHER_SESSION_ID,
                    title = OTHER_TITLE,
                    preview = "независимая сессия",
                    createdAt = "2026-09-30T08:00:00",
                    updatedAt = "2026-09-30T10:00:00",
                    messageCount = 0,
                ),
            )
        )
        check(saved) { "SessionOfflineCache отклонил запись фикстуры" }
        val savedMessages = cache.saveMessages(
            PARENT_SESSION_ID,
            listOf(
                SessionMessage(id = "m1", role = "user", content = CACHED_MESSAGE_TEXT),
                SessionMessage(id = "m2", role = "assistant", content = "Ответ из сохранённой копии"),
            )
        )
        check(savedMessages) { "SessionOfflineCache отклонил запись транскрипта" }
    }

    /**
     * Ждёт, пока [matcher] перестанет отображаться (или исчезнет из иерархии).
     *
     * Зачем отдельно от [waitUntilDisplayed]: экран перерисовывается отложенно
     * (дебаунс ввода, асинхронная загрузка), поэтому `check(doesNotExist())` сразу
     * после действия видит СТАРУЮ иерархию и падает не на поведении, а на гонке.
     */
    fun waitUntilGone(matcher: Matcher<View>, timeoutMs: Long = 20_000) {
        val deadline = SystemClock.uptimeMillis() + timeoutMs
        while (SystemClock.uptimeMillis() < deadline) {
            val gone = try {
                onView(matcher).check(matches(not(isDisplayed())))
                true
            } catch (missing: androidx.test.espresso.NoMatchingViewException) {
                // View больше нет в иерархии — ожидаемый исход «исчезло».
                true
            } catch (t: Throwable) {
                // Неоднозначный матчер ждать не имеет смысла — падаем сразу.
                if (hasCause(t, androidx.test.espresso.AmbiguousViewMatcherException::class.java)) {
                    throw AssertionError(
                        "Матчер неоднозначен — совпало несколько view. Уточните матчер: $matcher",
                        t,
                    )
                }
                // Иначе view ЕЩЁ видима — нормальный промежуточный результат, опрашиваем дальше.
                false
            }
            if (gone) return
            SystemClock.sleep(250)
        }
        throw AssertionError("View $matcher не исчезла за ${timeoutMs}ms")
    }

    /**
     * Есть ли в цепочке причин исключение типа [type].
     *
     * Нужно потому, что Espresso заворачивает свои сбои в
     * `AssertionFailedWithCauseError` (наследник [AssertionError]), так что судить по
     * верхнему типу исключения нельзя: «ещё видима» и «матчер неоднозначен» приходят
     * с одинаковой обёрткой и различаются только причиной.
     */
    private fun <T : Throwable> hasCause(error: Throwable, type: Class<T>): Boolean {
        var cause: Throwable? = error
        var guard = 0
        while (cause != null && guard++ < 10) {
            if (type.isInstance(cause)) return true
            cause = cause.cause
        }
        return false
    }

    /**
     * Ждёт (поллинг на main-idle между попытками), пока [matcher] не станет
     * отображаемым: асинхронная загрузка из кэша/сети не отслеживается
     * IdlingResource приложения.
     */
    fun waitUntilDisplayed(matcher: Matcher<View>, timeoutMs: Long = 20_000) {
        val deadline = SystemClock.uptimeMillis() + timeoutMs
        var lastError: Throwable? = null
        while (SystemClock.uptimeMillis() < deadline) {
            try {
                onView(matcher).check(matches(isDisplayed()))
                return
            } catch (t: Throwable) {
                // Неоднозначный матчер — это НЕ «ещё не появилось»: ждать бессмысленно,
                // условие не выполнится никогда. Проверяем по цепочке причин, потому что
                // Espresso заворачивает свой сбой в AssertionFailedWithCauseError.
                if (hasCause(t, androidx.test.espresso.AmbiguousViewMatcherException::class.java)) {
                    throw AssertionError(
                        "Матчер неоднозначен — совпало несколько view. Уточните матчер " +
                            "(allOf/withClassName): $matcher",
                        t,
                    )
                }
                lastError = t
                SystemClock.sleep(250)
            }
        }
        throw AssertionError("View $matcher не появилась за ${timeoutMs}ms", lastError)
    }
}
