package ru.mars.mobile

import ru.mars.network.repository.ServerTtsResult
import ru.mars.network.repository.ServerTtsVoiceProfile
import ru.mars.network.repository.ServerTtsVoices

/**
 * Выбор голосового профиля для голосового диалога: естественный голос веба — основной,
 * локальный piper — только запасной.
 *
 * Зачем: в вебе Марс говорит `edge` + `ru-RU-SvetlanaNeural`, а Android v1 слал запрос без
 * `engine`/`voice` и получал `piper` + `ru_RU-dmitri-medium` — другой движок, другое
 * произношение («Флэш» вместо «Слэш»). Порядок профилей задаётся явно:
 *
 * 1. [ServerTtsVoices.NATURAL_SVETLANA] — тот самый голос веба. Он ПЕРВЫЙ всегда, пока
 *    доступен: подменять его «более быстрым» локальным нельзя, это выбор пользователя.
 * 2. [ServerTtsVoices.LOCAL_IRINA] — piper, если установлен. Запасной путь на случай,
 *    когда сеть/edge недоступны: irina произносит «Слэш» верно без словаря, TTFB ~0.22 с.
 * 3. Если недоступны оба — [candidates] пуст, и вызывающий слой честно уходит на системный
 *    TTS (а не молчит и не выдумывает третий голос).
 *
 * Понижение профиля — по НАБЛЮДЕНИЮ, а не по догадке: серверного капабилити-эндпоинта
 * пока нет (контракт в работе), поэтому единственный достоверный источник — фактический
 * ответ `api/tts`. Виды отказа различаются:
 * - `429 rate_limited` — это лимитер (2 с на клиента), а НЕ отсутствие голоса: профиль НЕ
 *   понижается, повтор делает очередь ([SpeechQueue]). Иначе первая же очередь фраз
 *   навсегда переключила бы диалог на irina вопреки желанию пользователя;
 * - `401 unauthorized` — проблема токена, голос ни при чём: профиль тоже не понижается;
 * - `400/404/501` (голоса нет в `voices_dir`, движок не установлен) — понижение надолго;
 * - транспорт/`5xx`/битый ответ — понижение ненадолго, чтобы вернуться к естественному
 *   голосу, как только сеть оживёт.
 *
 * Перебор цепочки внутри одной реплики делает [RepositoryServerTtsClient]: он спрашивает
 * [candidates] по порядку и сообщает сюда фактический исход каждого профиля. Здесь
 * хранится только ЗНАНИЕ (что работает, что нет и почему) — политика «когда возвращаться
 * к желаемому голосу» тоже здесь, в виде пауз.
 *
 * Почему следующий ответ начинается с самого приоритетного профиля, а не с последнего
 * успешного: `503`/таймаут — свойство МОМЕНТА на сервере, а не текста, и «прилипание» к
 * резерву после одного сбоя навсегда подменило бы выбранный пользователем голос. Поэтому
 * пауза короткая (45 с) и после неё естественный голос пробуется снова. `400 invalid
 * voice` — свойство ЗАПРОСА (пары engine/voice), поэтому такая пара не дёргается каждую
 * фразу: долгая пауза, а для локального профиля — [LocalVoiceAvailability.ABSENT].
 * Экран при этом не остаётся без звука: пока один профиль на паузе, работает другой, а
 * когда не работает ни один — вызывающий слой честно уходит на системный TTS.
 *
 * @param profiles порядок предпочтения (первый — желаемый).
 * @param nowMs монотонные часы в мс (в тестах подменяются).
 * @param transientCooldownMs пауза перед повторной попыткой после сетевого сбоя.
 * @param permanentCooldownMs пауза после «голоса нет на сервере».
 * @param localVoice установленность локального piper-голоса. По умолчанию
 *   [LocalVoiceAvailability.UNVERIFIED] — «неизвестно», а НЕ «установлен»: серверного
 *   капабилити-эндпоинта пока нет, и объявлять голос установленным наугад значит обещать
 *   резерв, которого может не быть. Непроверенный профиль допускается к ОДНОЙ фактической
 *   попытке: ответ сервера (`200` → [LocalVoiceAvailability.INSTALLED], `400/404/501` →
 *   [LocalVoiceAvailability.ABSENT]) и есть настоящее доказательство.
 */
class SpeechVoiceProfileSelector(
    private val profiles: List<ServerTtsVoiceProfile> = ServerTtsVoices.VOICE_DIALOG,
    private val nowMs: () -> Long = { System.nanoTime() / 1_000_000L },
    private val transientCooldownMs: Long = DEFAULT_TRANSIENT_COOLDOWN_MS,
    private val permanentCooldownMs: Long = DEFAULT_PERMANENT_COOLDOWN_MS,
    localVoice: LocalVoiceAvailability = LocalVoiceAvailability.UNVERIFIED,
) {

    /** Что известно о локальном голосе: догадка не выдаётся за факт. */
    enum class LocalVoiceAvailability {
        /** Ни подтверждения, ни отказа: одна фактическая попытка допустима. */
        UNVERIFIED,

        /** Сервер реально отдал аудио этим голосом. */
        INSTALLED,

        /** Сервер ответил «голоса/движка нет» — больше не предлагаем. */
        ABSENT,
    }

    private val lock = Any()

    /** До какого момента профиль считается недоступным (id → время). */
    private val cooldownUntil = HashMap<String, Long>()

    /** Счётчик отказов по профилю — диагностика и тесты, решений не принимает. */
    private val failures = HashMap<String, Int>()

    @Volatile
    private var localState: LocalVoiceAvailability = localVoice

    /** Текущее знание о локальном голосе (диагностика; решений снаружи не принимает). */
    val localVoiceAvailability: LocalVoiceAvailability
        get() = localState

    /**
     * Причина последнего отказа: какой профиль, почему и с каким HTTP-кодом.
     *
     * Нужна, чтобы откат был не только наблюдаемым, но и объяснимым: без неё в логах
     * видно «голос сменился», но не видно «сервер ответил 503 Edge TTS engine not
     * installed». Текст запроса сюда не попадает — только метаданные.
     */
    data class Failure(val profileId: String, val reason: String, val httpCode: Int?)

    @Volatile
    var lastFailure: Failure? = null
        private set

    /**
     * Профиль, который РЕАЛЬНО зазвучал в этой сессии (последний успешный синтез).
     *
     * Это факт, а не предпочтение: следующий запрос всё равно начнётся с самого
     * приоритетного доступного профиля (см. KDoc класса), но приёмка и логи должны
     * видеть, каким голосом приложение говорило на самом деле.
     */
    @Volatile
    var lastSuccessfulProfile: ServerTtsVoiceProfile? = null
        private set

    /**
     * Профили, которые можно пробовать СЕЙЧАС, в порядке предпочтения.
     *
     * Пустой список — пробовать некого: вызывающий уходит на системный TTS.
     */
    fun candidates(): List<ServerTtsVoiceProfile> = synchronized(lock) {
        val now = nowMs()
        profiles.filter { profile ->
            isAvailableLocked(profile) && (cooldownUntil[profile.id] ?: 0L) <= now
        }
    }

    /** Первый доступный профиль или null. */
    fun current(): ServerTtsVoiceProfile? = candidates().firstOrNull()

    /**
     * Зафиксировать факт установленности локального голоса (когда появится капабилити сервера
     * или человек выбрал голос вручную). Значение — факт, а не догадка вызывающего.
     */
    fun setLocalVoiceInstalled(installed: Boolean) {
        localState = if (installed) {
            LocalVoiceAvailability.INSTALLED
        } else {
            LocalVoiceAvailability.ABSENT
        }
    }

    /** Сколько отказов накопил профиль (диагностика). */
    fun failureCount(profile: ServerTtsVoiceProfile): Int = synchronized(lock) {
        failures[profile.id] ?: 0
    }

    /** Профиль зазвучал: снимаем понижение и обнуляем счётчик отказов. */
    fun onAudio(profile: ServerTtsVoiceProfile) {
        synchronized(lock) {
            cooldownUntil.remove(profile.id)
            failures.remove(profile.id)
        }
        lastSuccessfulProfile = profile
        // Факт: сервер отдал аудио этим голосом — теперь он действительно установлен.
        if (profile.isLocal) localState = LocalVoiceAvailability.INSTALLED
    }

    /**
     * Синтез этим профилем не дал аудио.
     *
     * Причина фиксируется ВСЕГДА (даже когда профиль не понижается): решение о паузе и
     * знание «почему не зазвучало» — разные вещи, и второе нужно для разбора инцидентов.
     *
     * @return `true`, если профиль понижен (следующий запрос попробует другой голос);
     *   `false` — отказ не связан с голосом (`429`, `401`), порядок не меняется.
     */
    fun onUnavailable(profile: ServerTtsVoiceProfile, result: ServerTtsResult.Unavailable): Boolean {
        val now = nowMs()
        lastFailure = Failure(profile.id, result.reason, result.httpCode)
        synchronized(lock) {
            failures[profile.id] = (failures[profile.id] ?: 0) + 1
            if (!demotesProfile(result)) return false
            val cooldown = if (isPermanent(result)) permanentCooldownMs else transientCooldownMs
            cooldownUntil[profile.id] = now + cooldown.coerceAtLeast(0L)
            // «Голоса нет» — это не пауза, а факт: локальный профиль больше не предлагаем,
            // иначе каждый диалог заново пробовал бы несуществующий голос.
            if (profile.isLocal && isPermanent(result)) {
                localState = LocalVoiceAvailability.ABSENT
            }
            return true
        }
    }

    /** Сбросить все понижения (новый диалог, смена сети, ручной выбор голоса). */
    fun reset() {
        synchronized(lock) {
            cooldownUntil.clear()
            failures.clear()
        }
    }

    /**
     * Предлагается ли профиль сейчас.
     *
     * Сетевой профиль — всегда (его наличие определяет сервер, отказ придёт ответом).
     * Локальный — только если не доказано обратное: `ABSENT` исключает его насовсем,
     * `UNVERIFIED` даёт одну фактическую попытку, `INSTALLED` — обычный кандидат.
     */
    private fun isAvailableLocked(profile: ServerTtsVoiceProfile): Boolean =
        profile.needsNetwork || localState != LocalVoiceAvailability.ABSENT

    /**
     * Понижает ли такой отказ профиль.
     *
     * `rate_limited` и `unauthorized` — нет: лимитер и токен не говорят о наличии голоса,
     * и понижение здесь подменило бы желаемый голос из-за чужой проблемы.
     */
    private fun demotesProfile(result: ServerTtsResult.Unavailable): Boolean =
        result.reason != "rate_limited" && result.reason != "unauthorized"

    /** «Голоса/движка нет» — это надолго; сетевые и серверные сбои — ненадолго. */
    private fun isPermanent(result: ServerTtsResult.Unavailable): Boolean {
        val code = result.httpCode
        if (code != null && (code == 400 || code == 404 || code == 501)) return true
        return result.reason == "not_found" || result.reason == "invalid_voice"
    }

    companion object {
        /** Сетевой сбой: через 45 с снова пробуем естественный голос. */
        const val DEFAULT_TRANSIENT_COOLDOWN_MS: Long = 45_000L

        /** Голоса нет на сервере: не дёргаем его 10 минут (модель могут доустановить). */
        const val DEFAULT_PERMANENT_COOLDOWN_MS: Long = 600_000L
    }
}
